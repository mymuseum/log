Summary of changes

#### Benefits
+ It's awesome
+ It's helpful

#### Potential Issues
- Possible Issue
- Possible Issue
