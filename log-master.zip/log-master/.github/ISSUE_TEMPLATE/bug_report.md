![Optional screenshot](screenshot.png)

[Description of the issue]

#### Steps to Reproduce
1. Do this
2. Then this

**Expected:** [Expectations]
**Actual:** [Reality]

#### Possible Fix
[If you have an idea of how to fix the issue, submit a PR instead. But if you'd like, you may propose a fix here]

**Version:** [0.0.0]
**OS:** [OS name & version]
