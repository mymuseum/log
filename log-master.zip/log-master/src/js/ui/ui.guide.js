module.exports = {

  build () {

  },

  toc () {

  },

  content () {

  },

  about () {

  }
};
